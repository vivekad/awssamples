/**
 * 
 */
package com.aws.sample.billing;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.accounts.AmazonAccountsServiceClient;
import com.amazonaws.services.accounts.model.Address;
import com.amazonaws.services.accounts.model.CreateLinkedAccountRequest;
import com.amazonaws.services.accounts.model.MailingAddress;

/**
 * @author viveka
 *
 */
public class CreateLinkedAccountMain {

	private static final String SECRET_KEY = "";
	private static final String ACCESS_KEY = "";
	private static final String SNS_TOPIC = "arn:aws:sns:us-east-1:453272712372:ExampleSNSTopic";
	private static final String ROLE_NAME = "PayerAccountAccessRole";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//All undeclared parameters are String objects that are 
		//initialized before this example

		//First we instantiate an object to hold our IAM user credentials
		BasicAWSCredentials creds = new BasicAWSCredentials(ACCESS_KEY, SECRET_KEY);

		//Now we create our handle to the service and give it the credentials
		//we want to use
		AmazonAccountsServiceClient aas = new AmazonAccountsServiceClient(creds);
		aas.setServiceNameIntern("AWSAccountsService");

		//Now we need to create the parameters we are going to call the API with
		//We instantiate a MailingAddress object and set the data in it
		MailingAddress mailingAddress = new MailingAddress();
		//You can also call .setAddressLine2 and .setAddressLine3 if you need to
		mailingAddress.setAddressLine1("123 4th Ave");
		mailingAddress.setCity("Seattle");
		mailingAddress.setStateOrRegion("Washington");
		mailingAddress.setCountryCode("US");
		//Remember that the postal code must be the full code (5+4)
		mailingAddress.setPostalCode("98101-1210");
			
		//Now we instantiate our contact address which includes the
		//mailing address, our name, and our contact phone number
		Address address = new Address();
		address.setFirstName("John");
		address.setLastName("Smith");
		address.setMailingAddress(mailingAddress);
		address.setPhoneNumber("1234567890");
			
		//Now let's create the request we are going to pass to the service
		CreateLinkedAccountRequest ClaRequest = new CreateLinkedAccountRequest();
		//And populate the data in that request
		ClaRequest.setAddress(address);
		ClaRequest.setEmail("vadlakha@yahoo.com");
		//Remember that the service's account needs permission to post to this topic
		ClaRequest.setSnsArn(SNS_TOPIC);
		// Set the name of the IAM role the payer will use to access the account
		ClaRequest.setRoleName(ROLE_NAME);

		//And finally let's make the call to the service.  This will throw
		//an exception if the API is not successful, otherwise you can
		//assume the workflow was started
		aas.createLinkedAccount(ClaRequest);
	}

}
